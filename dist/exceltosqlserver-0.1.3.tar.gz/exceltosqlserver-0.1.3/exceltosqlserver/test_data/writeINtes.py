# -*- coding:utf-8 -*-
##############################################################
# Created Date: Tuesday, December 29th 2020
# Contact Info: luoxiangyong01@gmail.com
# Author/Copyright: Mr. Xiangyong Luo
##############################################################


def writeTest(msg):
    print(msg)
    
def writeTest1(msg):
    print(msg)